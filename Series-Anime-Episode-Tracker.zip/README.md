# Series & Anime Episode Tracker

## What's this addon for?

It tracks the episodes on your series & anime websites and shows your last seen ones

## Why???

Just a little experiment for myself to test the firefox extension api and just idk :D
Feel free to contribute

## Where can i find this crab?

I still have to publish it :( (if you can read this then it is already public)